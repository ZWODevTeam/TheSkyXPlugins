This is TheSkyX plug-in installer for Mac OSX & Linux & ARM platform, it's provided by ZWO company, supports all released EFW filter wheel.
Before you run the installer, you have to launch TheSkyX at least once, otherwise the installer won't find the TheSkyX directory.
then Type
chmod +x install.bin
./install.bin
uninstall file will be generated if install successfully.
replug your device(camera/filter wheel/focuser).

Uninstall:
./uninstall

Any questions please contact: yang.zhou@zwoptical.com.
